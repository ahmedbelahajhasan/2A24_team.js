# send-sms
This is a Send SMS PHP Script using MessageBird API by Pure Coding.

Sorry Guys for providing Zip file.
